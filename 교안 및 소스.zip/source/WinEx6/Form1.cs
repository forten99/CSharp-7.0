﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WinEx6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //checkedListBox.Items.Add("미국");

            checkedListBox.SetItemChecked(2, true);
            checkedListBox.SetItemChecked(4, true);
        }

        private void checkedListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = checkedListBox.SelectedIndex;
            string item = checkedListBox.SelectedItem.ToString();
            Debug.WriteLine(idx + " : " + item + " 선택됨");
        }
    }
}
