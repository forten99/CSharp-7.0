﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqEx5
{
    /*
        from a in A
        join b in B on a.XXX equals b.XXX into temp
        from b in temp.DefaultEmpty(new a() {empty = ""})
    */
    class Student
    {
        public string name { get; set; } 
        public int age { get; set; }
    }

    class Score
    {
        public string name { get; set; }
        public int math { get; set; }
        public int english { get; set; }
    }

    class Program
    {        
        static void Main(string[] args)
        {
            Student[] studentList =
            {
                new Student(){name = "김말똥", age = 21},
                new Student(){name = "이길동", age = 22},
                new Student(){name = "김길동", age = 23},
                new Student(){name = "홍길북", age = 24}
            };
        
            Score[] scoreList =
            {
                new Score(){ name = "김말똥", math = 98, english = 77},
                new Score(){ name = "김길동", math = 88, english = 66},
                new Score(){ name = "홍길북", math = 69, english = 99},
                new Score(){ name = "강길동", math = 79, english = 88}
            };

            var Students = from student in studentList
                           join score in scoreList on student.name equals score.name into temp
                           from score in temp.DefaultIfEmpty(new Score() { math = 100, english = 100 })
                           select new
                           {
                               Name = student.name,
                               Age = student.age,
                               Math = score.math,
                               English = score.english
                           };
            foreach (var student in Students)
                Console.WriteLine(student);
    
        }
    }
}
