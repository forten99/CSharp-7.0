﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    확장 메소드 : 기존 클래스의 기능을 확장하는 기법, 상속과 구별하여 생각하면 이해하기가 쉽다.

    [ 선언 형식 ]

    public static class 클래스이름
    {
        public static 반환형식 메소드명( this 대상형식(클래스, 타입) 식별자, 매개변수)
        {
        }
    }

*/
namespace ExtensionEx
{
    public static class MyExtension
    {
        public static void ShowMyIntList(this int n, int n2)
        {
            Console.WriteLine($"int 값은 {n}, {n2} ");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int n = 100;

            n.ShowMyIntList(200);

            1000.ShowMyIntList( 2000 );
        }
    }
}
