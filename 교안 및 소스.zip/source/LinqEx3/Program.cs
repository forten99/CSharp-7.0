﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqEx3
{
    // group by

    // 형식
    // group X by Y into Z
    // X는 from절에서 가져온 범위 변수
    // Y는 분류기준
    // Z는 그룹변수

    class Member
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Member[] memberList =
            {
                new Member(){Name = "강호동", Age = 49},
                new Member(){Name = "이경규", Age = 23},
                new Member(){Name = "이경실", Age = 33},
                new Member(){Name = "손흥민", Age = 26},
                new Member(){Name = "김연아", Age = 55}
            };

            var GroupMember = from member in memberList
                        group member by member.Age > 30 into g
                        select new { groupKey = g.Key, members = g };

            foreach(var Group in GroupMember)
            {
                if (Group.groupKey)
                {
                    Console.WriteLine("<30대 멤버>");
                    foreach (var member in Group.members)
                        Console.WriteLine($"이름 : {member.Name} 나이: {member.Age}");
                }
                else
                {
                    Console.WriteLine("<30대 미만 멤버>");
                    foreach (var member in Group.members)
                        Console.WriteLine($"이름: {member.Name} 나이: {member.Age}");
                }
            }
        }
    }
}
