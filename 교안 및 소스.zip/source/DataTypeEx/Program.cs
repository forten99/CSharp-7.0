﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypeEx
{
    class Program
    {
        static void Main(string[] args)
        {
            /* C# 데이터 타입
             * 
             * .NET 프로그래밍 언어는 .NET 공용 타입 형식을 사용한다.
             * 
             * 
             * int, double, string 키워드로 데이터 타입을 표현
             * 
             * System.Int32, System.Double, System.String(.NET의 클래스로 데이타 타입을 표현하는 방법)
             * 
             * 
             * ---- 논리형 --------
             * bool : True or False
             * 
             * ---- 정수형 --------
             * byte : 8비트 unsigined 정수형(integer)
             * sbyte : 8비트 signed 정수형
             * (u)short : 16비트 (un)signed 정수형
             * (u)int : 32비트 (un)signed 정수형
             * (u)long : 64비트 (un)signed 정수형
             * 
             * ----- 실수형 --------
             * float : 32비트 실수형
             * double : 64비트 실수형
             * decimal : 128비트 실수형(folat, double 보다 더 정밀한 소수를 다룬다.)
             * 
             * ----- 문자열 형------
             * char : 16비트 유니코드 문자
             * string : 유니코드 문자열                          
            
            
             변수 선언
            int x;
            변수의 초기화
            x = 1000;

            선언과 초기화를 동시에
            int y = 2000;

            여러개의 변수를 동시에 선언하기
            int a, b, c;

            a = 1000;
            b = 2000;
            c = 3000;

            여러개의 변수 선언과 초기화 동시에 하기
            double z=12.1, kk = 11.11, zz=22.22

            */

            char a = 'H';
            char b = 'e';
            char c = 'l';
            char d = 'l';
            char e = 'o';

            //Console.Write(a);
            //Console.Write(b);
            //Console.Write(c);
            //Console.Write(d);
            //Console.Write(e);

            string str = "Hello";
            Console.WriteLine(str);
                       

            // 리터럴 데이터 : 123, True, "AGC" 와 같은 값들을 리터럴(Literal)이라 한다.
            // 리터럴의 형식(타입) : 
            // 123(int 리터럴), 11.11(double 리터럴), "B"(string 리터럴), 'b'(cahr 리터럴), True(bool 리터럴)

            // C# 컴파일러는 int, double, char, string, bool 데이터 타입에 기본적으로 
            // 그에 해당하는 값을 할당한다.

            // 데이터 타입별 접미사(Suffix)를 사용해서 특정 데이터 타입을 지정할 수 있다.
            // [ 접미어 ]
            // L : long형, U: Uint, UL:Ulong, F:float, D:double, M:decimal
            
            long l = 12322L;

            // int 형의 최대 수치
            int aa = int.MaxValue;
            int aa_ = int.MinValue;

            long bb_ = long.MinValue;
            long bb = long.MaxValue;

            float f_ = float.MinValue;
            float f = float.MaxValue;

            Console.Write(aa_);
            Console.Write(" ~ ");
            Console.WriteLine(aa);
            Console.WriteLine();
            Console.Write(bb_);
            Console.Write(" ~ ");
            Console.WriteLine(bb);
            Console.WriteLine();
            Console.Write(f_);
            Console.Write(" ~ ");
            Console.WriteLine(f);


            // NULL: 어떤 변수가 데이터를 가지고 있지 않을 때 표현방법
            // 즉, 메모리상에 어떤 데이터도 갖고 있지 않을 때 사용하는 키워드이다.

            // NULL을 가질 수 있는 데이터 타입(Reference 타입)이 있는데, 대표적으로 String 타입은
            // NULL을 가질 수 있는 타입니다. 
            // NULL을 가질 수 없는 타입은 Value타입(int, DateTime..)


            // 

            string str1;
            str1 = null;
            Console.Write(str1);
            Console.ReadKey();
            
        }
    }
}
