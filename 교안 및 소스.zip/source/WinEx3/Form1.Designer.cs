﻿namespace WinEx3
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.label_sel = new System.Windows.Forms.Label();
            this.listBox_info = new System.Windows.Forms.Label();
            this.comboDropDownList = new System.Windows.Forms.ComboBox();
            this.comboSimple = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(44, 173);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(121, 20);
            this.comboBox.TabIndex = 0;
            this.comboBox.Text = "선택하세요";
            this.comboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 12;
            this.listBox.Location = new System.Drawing.Point(206, 55);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(149, 112);
            this.listBox.TabIndex = 1;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label_sel
            // 
            this.label_sel.AutoSize = true;
            this.label_sel.Location = new System.Drawing.Point(204, 288);
            this.label_sel.Name = "label_sel";
            this.label_sel.Size = new System.Drawing.Size(65, 12);
            this.label_sel.TabIndex = 2;
            this.label_sel.Text = "선택 항목 :";
            // 
            // listBox_info
            // 
            this.listBox_info.AutoSize = true;
            this.listBox_info.Location = new System.Drawing.Point(277, 288);
            this.listBox_info.Name = "listBox_info";
            this.listBox_info.Size = new System.Drawing.Size(33, 12);
            this.listBox_info.TabIndex = 3;
            this.listBox_info.Text = " ----";
            // 
            // comboDropDownList
            // 
            this.comboDropDownList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboDropDownList.FormattingEnabled = true;
            this.comboDropDownList.Location = new System.Drawing.Point(44, 264);
            this.comboDropDownList.Name = "comboDropDownList";
            this.comboDropDownList.Size = new System.Drawing.Size(121, 20);
            this.comboDropDownList.TabIndex = 4;
            this.comboDropDownList.SelectedIndexChanged += new System.EventHandler(this.comboDropDownList_SelectedIndexChanged);
            // 
            // comboSimple
            // 
            this.comboSimple.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.comboSimple.FormattingEnabled = true;
            this.comboSimple.Location = new System.Drawing.Point(44, 54);
            this.comboSimple.Name = "comboSimple";
            this.comboSimple.Size = new System.Drawing.Size(121, 90);
            this.comboSimple.TabIndex = 5;
            this.comboSimple.SelectedIndexChanged += new System.EventHandler(this.comboSimple_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 332);
            this.Controls.Add(this.comboSimple);
            this.Controls.Add(this.comboDropDownList);
            this.Controls.Add(this.listBox_info);
            this.Controls.Add(this.label_sel);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.comboBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Label label_sel;
        private System.Windows.Forms.Label listBox_info;
        private System.Windows.Forms.ComboBox comboDropDownList;
        private System.Windows.Forms.ComboBox comboSimple;
    }
}

