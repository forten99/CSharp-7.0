﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinEx3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] list = { "1번", "2번", "3번", "4번" };

            // 각 콤보박스에 item 설정
            comboSimple.Items.AddRange(list);
            comboBox.Items.AddRange(list);
            comboDropDownList.Items.AddRange(list);

            // 초기 선택값 지정
            comboSimple.SelectedIndex = 0;
            comboDropDownList.SelectedIndex = 0;
        }

        string[] list1 = { "사과", "오렌지", "바나나" };
        string[] list2 = { "서울", "부산", "대구", "광주" };
        string[] list3 = { "대한민국", "중국", "미국", "북한" };
        string[] list4 = { "축구", "야구", "배구", "농구" };


        // SelectedIndexChanged 이벤트는 아이템들 중에서 다른 아이템을 선택 했을 때 발생하는 이벤트
        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();

            if (comboBox.SelectedIndex == 0) listBox.Items.AddRange(list1);
            if (comboBox.SelectedIndex == 1) listBox.Items.AddRange(list2);
            if (comboBox.SelectedIndex == 2) listBox.Items.AddRange(list3);
            if (comboBox.SelectedItem.ToString() == "4번") listBox.Items.AddRange(list4);


        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_info.Text = listBox.SelectedItem.ToString();
        }



        private void comboSimple_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();

            if (comboSimple.SelectedIndex == 0) listBox.Items.AddRange(list1);
            if (comboSimple.SelectedIndex == 1) listBox.Items.AddRange(list2);
            if (comboSimple.SelectedIndex == 2) listBox.Items.AddRange(list3);
            if (comboSimple.SelectedItem.ToString() == "4번") listBox.Items.AddRange(list4);
        }

        private void comboDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            // control.Items.Add('가나다')
            // control.Items.AddRange()는 한꺼번에 데이터를 입력
            if (comboDropDownList.SelectedIndex == 0) listBox.Items.AddRange(list1);
            if (comboDropDownList.SelectedIndex == 1) listBox.Items.AddRange(list2);
            if (comboDropDownList.SelectedIndex == 2) listBox.Items.AddRange(list3);
            if (comboDropDownList.SelectedItem.ToString() == "4번") listBox.Items.AddRange(list4);
        }
    }
}
