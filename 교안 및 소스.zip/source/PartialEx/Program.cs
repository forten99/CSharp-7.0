﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    Partial Type

    c#2.0에서 도입 partial class, partial struct, partial interface


*/
namespace PartialEx
{
    partial class MyClass
    {
        public void aaa()
        {
            Console.WriteLine("aaa 메소드 호출");
        }

        public void bbb()
        {
            Console.WriteLine("bbb 메소드 호출");
        }        
    }

    partial class MyClass
    {
        public void ccc()
        {
            Console.WriteLine("ccc 메소드 호출");
        }

        public void ddd()
        {
            Console.WriteLine("ddd 메소드 호출");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyClass mc = new MyClass();
            mc.aaa();
            mc.bbb();
            mc.ccc();
            mc.ddd();
        }
    }
}
