﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        '이름을 저장하기 위한 변수 선언
        Dim 성명 As String
        '학과몀을 저장하기 위한 변수 선언
        Dim 학과명 As String

        '입력된 이름과 학과를 선언된 변수에 각각 대입
        성명 = TextBox1.Text
        학과명 = TextBox2.Text

        '변수에 저장된 이름과 학과를 출력 
        TextBox3.Text = 성명
        TextBox4.Text = 학과명
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
