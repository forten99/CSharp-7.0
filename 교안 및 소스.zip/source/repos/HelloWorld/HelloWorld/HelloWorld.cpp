// HelloWorld.cpp : +-z1jBlA- +-x1HGqQ- +-1QS4XK34t6jF0A- +-swDVXA- +-ycTHhcgQx0Q- +-yBXHWNVpssiy5A-.
//
+-ACM-include +-ACI-stdafx.h+-ACI-
+-ACM-include +-ADw-iostream+-AD4-

// main +-1WjCGMdY- 3+-yIW5WA- +-0MDHhQ-
// int main()+-AHs- +-z1S03A- +-AH0-
// int main(int argc, char +-ACo-argv+-AFsAXQ-)+-AHs- +-z1S03A- +-AH0-
// int main(int argc, char +-ACo-argv+-AFsAXQ-, parameters)+-AHs- +-z1S03A- +-AH0-


/+-ACoAKg- +-rHDHWA- +-uqi04A- +-wtzCpNFcx0A- 3+-yIW5WMdY- +-1FzJAA- +-x4XNnLglx0Q- +-rjC8+-Mc8uFw- +-yBys9dVcsuQ-.
	
	+-1FzJAMeFuCU-: Standard input  --+-AD4- stdin
	+-1FzJAMeFuCU-: Standard output --+-AD4-stdout
	+-1FzJAMXQt+-zNnLgl-: Standard error --+-AD4-stderr
+-ACo-/ 

using namespace std+-ADs-


int main()
+-AHs-

	//std+-spQ- +-ACI-standard+-ACLHWA- +-xX3HkA- : +-1FzJAA- +-sSTHhMKk05jHdMKkuXw- +-x1i7+-A-
	// :: +-s1S+-FM9cuGA-, +-vJTHBNZVx3jF8MCwx5A-(Scope resolution operator)
	// endl+-spQ- end of line (+-AFw-n : +-yQS8FK/I-, +-rBzVibs4x5A-)

	// std::cout +-1FzJAA- +-zZy4JbzAwhg- +-0MDHhcdA- ostream
	/+-ACo-std::cout +-ADwAPA- +-ACI-Hello World+-ACEAIQAhACEAIg- +-ADwAPA- std::endl+-ADs-
	std::cout +-ADwAPA- +-ACI-Hello +-ACI- +-ADwAPA- +-ACI-World+-ACEAIQAhACI- +-ADwAPA- std::endl+-ADs-
    return 0+-ADsAKg-/

	// std::cin +-1FzJAA- +-x4W4JbzAwhg- +-0MDHhcdA- istream
	/+-ACo- +-wKzGqbyV-
		int m, k+-ADs-
		std::cin +-AD4APg- m +-AD4APg- k+-ADs-

		std::cout +-ADwAPA- m +-ADwAPA- ' ' k +-ADwAPA- std::endl+-ADs-
	+-ACo-/ 

	// std::cerr +-1FzJAA- +-xdC37A- +-zZy4JbzAwhg- +-0MDHhcdA- ostream
	/+-ACo- +-wKzGqbyV-
		std::cerr +-ADwAPA- +-ACLF0Lfs- +-vBzA3QAi- +-ADwAPA- std::endl+-ADs-

	+-ACo-/

	int num+-ADs-

	cout +-ADwAPA- +-ACI-Enjoy C+--+--.+-AFw-n+-ACIAOw-
	cin +-AD4APg- num+-ADs-

	cout +-ADwAPA- +-ACLHhbglrBI- : +-ACI- +-ADwAPA- num+-ADs-
+-AH0-

