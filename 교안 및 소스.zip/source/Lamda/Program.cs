﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lamda
{
    // 람다식 : 익명 메소드를 만들기 위해 사용하는 식
    // 람다식으로 만들어진 익명 메소드를 무명 함수(Anonymous Function)

    /* 람다식 선언 형식 

       매개변수목록 => 식

        " => " 이 연산자를 입력 연산자라 한다.

        delegate int AAA(int x, int y);

        static void Main(sring[] args)
        {
            AAA aaa = (int x, int y) => x+y;

            위의 코드는 다음과 같이 바꿔서 사용 가능
            AAA aaa = (x, y) => x+y;
        }

        위의 익명 메소드(무명함수)는 기존의 익명 메소드를 사용하던 것 보다 간소화 되었다.

        델리게이트를 사용하던 방식으로 구현을 해보면 아래와 같음

        delegate int AAA(int x, int y);

        static void Main(string[] args)
        {
            AAA aaa = delegate(int x, int y)
                      {
                        return x+y;
                      };
        }
    */


    class Program
    {
        delegate int Sum(int x, int y);

        static void Main(string[] args)
        {
            Sum sum = (x, y) => (x + y);

            Console.WriteLine($"{sum(10, 20)}");
        }
    }
}
