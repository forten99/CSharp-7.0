﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LamdaEx2
{
    // 매개변수목록 => {
    //                  실행 코드....                
    //               }
    /*
        대리자 인스턴스 =  ( ) =>
                     {
                        실행코드... ...
                     }
    */

    class Program
    {
        delegate string SumString(string[] args);

        static void Main(string[] args)
        {
            SumString sumString = (str) =>
            {
                string stringRes = "";
                foreach (string s in str)
                    stringRes += s;

                return stringRes;
            };

            Console.WriteLine(sumString(args));
        }
    }
}
