﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
    LINQ(Language INtegrated Query) : c# 언어에 통합된 데이터 질의 기능

*/

namespace LinkEx
{
    class Member
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Member[] memberList = {
                new Member(){Name="홍길동", Age = 24},
                new Member(){Name="이순신", Age = 55},
                new Member(){Name="고길서", Age = 43},
                new Member(){Name="김말똥", Age = 28},
                new Member(){Name="강말똥", Age = 35}
            };


            //List<Member> members = new List<Member>();
            //foreach(Member member in memberList)
            //{
            //    if (member.Age >= 30)
            //        members.Add(member);
            //}

            //members.Sort(
            //    (member1, member2) => {
            //        return member1.Age - member2.Age;
            //    });                 


            var members = from member in memberList
                          where member.Age >= 30
                          orderby member.Name descending
                          //select member.Name;
                          select new { member.Name, Age = member.Age + "세" };

            foreach (var member in members)
                //Console.WriteLine($"{member.Name}, {member.Age}");
                Console.WriteLine($"{member.Name}, {member.Age}");
        }
    }
}
/*
    [ LINQ ] 
        LINQ의 질의표현식(Query Expression)은 from 절로 시작한다.

        - from 절 다음에는 데이터 원본이 온다. 데이터 원본은 배열, 컬렉션 등이 올 수 있다.
          IEnumerable<T>
          
            from <범위변수> in <데이터원본>

            int[] aaa = {11,22,33,44,55}

            var res = from a in aaa
                      where a % 2 !=0
                      orederby a
                      select a;
            
        - where 절은 범위변수의 조건을 지정하여 그 조건에 해당하는 데이터를 걸러내는 역할을 한다.
        
        - orderby절은 where절에서 걸러낸 데이터를 정렬하는 역할을 한다.
          기본 정렬값은 오름차순(ascending)이다.

        - select절은 질의의 최종 결과를 가져온다.  
*/