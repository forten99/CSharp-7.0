﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptonEx3
{
    // 7.0에서 throw문 표현식(expression)
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int? aa = null;
                int bb = aa ?? throw new ArgumentNullException();
            }
            catch(ArgumentNullException ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                int[] arr = { 11, 22, 33, 44 };
                int idx = 4;
                int value = arr[idx >= 0 && idx < 4 ? idx : throw new IndexOutOfRangeException()];
                Console.WriteLine(value);
            }
            catch(IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
