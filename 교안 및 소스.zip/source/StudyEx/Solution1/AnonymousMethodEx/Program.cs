﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodEx
{
    //익명 메소드(Anonymous Method) : 이름이 없는 메소드 

    // 선언 형식
    /*
        델리게이트 인스턴스 = delegate(매개변수)
                           {
                              실행 코드...
                           } 

    */
    delegate int CalDelegate(int x, int y);

    class Program
    {
    
        static void Main(string[] args)
        {
            CalDelegate cd;

            cd = delegate (int x, int y)
                 {
                    return x + y;
                 };

            Console.WriteLine($"{cd(10, 20)}");
        }
    }
}
