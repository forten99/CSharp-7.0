﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionFilterEx
{
    // Exception Filter : catch절이 받아들일 예외 객체에 제약사항을 주고 그사항에 만족하는 경우에
    //                    예외 처리를 실행할 수 있도록 하는 기능

    // catch문 뒤에 when 키워드를 이용

    // 모든 예외 객체는 System.Exception 클래스로 부터 파생 된다.
    // 사용자 정의 예외 클래스를 만들때도 역시 System.Exception 클래스를 상속받아서 만든다.

    //사용자 정의 예외 클래스
    class UserException : Exception
    {
        public int ErrorCode { get; set; }
    }

    class Program
    {        

        static void Main(string[] args)
        {
            try
            {
                Console.Write("0~5 숫자 중 하나를 입력하시오 : ");
                string numTxt = Console.ReadLine();

                int num = Int32.Parse(numTxt);

                if (num < 0 || num > 5)
                    throw new UserException() { ErrorCode = num };
                else
                    Console.WriteLine($"{num}");
            }
            catch (UserException ex) when (ex.ErrorCode <0)
            {
                Console.WriteLine("음수는 사용 할 수 없습니다.");
            }
            catch(UserException ex) when (ex.ErrorCode > 5)
            {
                Console.WriteLine("5보다 큰 수는 사용할 수 없습니다.");
            }
        }
    }
}
