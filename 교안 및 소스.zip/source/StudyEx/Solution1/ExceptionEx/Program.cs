﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 예외 처리(Exception Handling)
/*
    예외 처리 구문

    try
    {
        // 실행코드
    }
    catch(Exception 객체1)
    {
        // 예외가 발생했을 때 처리 코드
    }
    catch(Exception 객체2)
    {
        // 예외가 발생했을 때 처리 코드
    }

*/
namespace ExceptionEx
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4 };

            try
            {
                for (int i = 0; i < 6; i++)
                {
                    Console.WriteLine(array[i]);
                }
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine($"오류가 발생했습니다 : {e.Message}");
            }

            Console.WriteLine("프로그램 종료!!");
        }
    }
}
