﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionEx4
{
    //try~catch finally
    // finally절은 예외가 발생하더라도 반드시 실행되는 절이다.
    class Program
    {
        static int divideMethod(int a, int b)
        {
            try            {

                return a / b;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("나누기 예외 발생함");
                throw ex;
            }
        }
        static void Main(string[] args)
        {
            try
            {
                Console.Write("a/b 수식에서 a의 값을 입력하세요 : ");
                string aa = Console.ReadLine();
                int a = Convert.ToInt32(aa);

                Console.Write("a/b 수식에서 b의 값을 입력하세요 : ");
                string bb = Console.ReadLine();
                int b = Convert.ToInt32(bb);

                Console.WriteLine($"{a}/{b} = {divideMethod(a, b)}");
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("에러 : " + ex.Message);
            }
            finally
            {
                Console.WriteLine("프로그램 종료");
            }

        }
    }
}
