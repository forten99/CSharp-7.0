﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// 델리게이트 : 메소드를 다른 메소드로 전달할 수 있도록 하기 위해서 만들어 진 것

/*
    void AAA(int arg1){ ... }

    int a = 123;
    AAA(a);

    class DemoClass
    {
        int id;
        string name;
        public void DisplayInfo() { }
    }

    void AAA(DemoClass d){ ... }

    DemoClass d = new DemoClass();
    AAA(d);

    ---------------Delegate를 이용한 메소드를 전달 ---------------

    void AAA(MyDelegate method) { .... }

    delegate int MyDelegate(string str);


    int StringToInt(string str) { .... }
    MyDelegate myDelegate = new MyDelegate(StringToInt);

    AAA(myDelegate);
*/

namespace DelegateEx
{
    class Program
    {
        // 델리게이트 정의
        delegate int MyDelegate(string str);

        void TestMethod()
        {
            // 델리게이트 객체 생성
            MyDelegate md = new MyDelegate(StringToInt);
            Aaa(md);
        }

        // 델리게이트에 대상이 되는 메소드
        int StringToInt(string str)
        {
            return int.Parse(str);
        }

        // 델리게이트를 전달 받는 메소드
        void Aaa(MyDelegate md)
        {
            int i = md("100");
            Console.WriteLine(i);
        }

        static void Main(string[] args)
        {
            new Program().TestMethod();
        }
    }
}
