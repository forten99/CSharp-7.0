﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullOperatorEx
{
    // ? : Nullable 타입을 선언할 때 사용하는 연산자

    // ?? 널 병합연산자 : 왼쪽의 피연산자가 null인지 체크하고, null인 경우에는 오른쪽 피연산자를 리턴
    //                  null이 아니면 왼쪽 피연산자를 그대로 리턴한다.
    // a ?? 100 에서 a값이 null이면 100을 리턴하고, a가 null이 아니면 a의 값을 리턴한다.
    class Program
    {
        static void Main(string[] args)
        {
            int? bb = null;
            Console.WriteLine($"{bb ?? 10}");

            bb = 12;
            Console.WriteLine($"{bb ?? 10}");

            string str = null;
            Console.WriteLine($"{str ?? "null값 입니다."}");

            str = "널이 아님";
            Console.WriteLine($"{str ?? "null값 입니다."}");
        }
    }
}
