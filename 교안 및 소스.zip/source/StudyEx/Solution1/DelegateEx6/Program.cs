﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEx6
{
    // delegate 체인 : 델리게이트 하나가 여러개의 메소드를 동시에 참조하는 것

    delegate void CalDelegate(int x, int y);
    class Program
    {
        static void Add(int x, int y)
        {
            Console.WriteLine(x + y);
        }

        static void Subtract(int x, int y)
        {
            Console.WriteLine(x - y);
        }

        static void Multiply(int x, int y)
        {
            Console.WriteLine(x * y);
        }

        static void Divide(int x, int y)
        {
            Console.WriteLine(x / y);
        }

        static void Main(string[] args)
        {
            CalDelegate cd = Add;
            cd += Subtract;
            cd += Multiply;
            cd += Divide;

            cd -= Multiply;


            //CalDelegate cd = new CalDelegate(Add)
            //    + Subtract
            //    + Multiply
            //    + Divide;



            //CalDelegate cd = (CalDelegate)Delegate.Combine(
            //    new CalDelegate(Add),
            //    new CalDelegate(Subtract),
            //    new CalDelegate(Multiply),
            //    new CalDelegate(Divide)
            //    );

            cd(10, 5);

        }
    }
}
