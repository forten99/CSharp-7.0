﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollectionsEx4
{
    //Dictionary<TKey, TValue>
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();

            dic["apple"] = "사과";
            dic["orange"] = "오렌지";
            dic["banana"] = "바나나";
            dic["watermelon"] = "수박";

            Console.WriteLine(dic["apple"]);
            Console.WriteLine(dic["orange"]);
            Console.WriteLine(dic["watermelon"]);
            Console.WriteLine(dic["banana"]);
        }
    }
}
