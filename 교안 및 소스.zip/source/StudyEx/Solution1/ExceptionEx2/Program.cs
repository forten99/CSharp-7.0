﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// System.Exception 클래스는 모든 Exception의 Base 클래스 이다.

// 앞서 사용했던 IndexOutOfRangeException 예외 클래스도 System.Exception으로 부터 파생된 것

// System.Exception을 이용해서 모든 예외사항을 처리하지 않는 이유
// 개발자가 예상하지 못했던 예외를 처리할 수는 있지만 처리하지 않아도 될 예외까지 모두
// 처리를 하므로써 오류가 발생할 수 있기 때문에 System.Exception을 사용하는 것은 신중하게 고려해야 한다.

// throw문 

//    try
//    {
//      throw new Exception("예외를 던짐");
//    }
//    catch(Exception e)
//    {
//      Console.WriteLine(e.Message);
//    }

namespace ExceptionEx2
{
    
    class Program
    {
        static void throwMethod(int aa)
        {
            if (aa < 5)
            {
                Console.WriteLine($"{aa}");
            }
            else
            {
                throw new Exception("aa는 5이상의 값이다.");
            }
        }
        static void Main(string[] args)
        {
            try
            {

                throwMethod(1);
                throwMethod(2);
                throwMethod(3);
                throwMethod(4);
                throwMethod(5);
                throwMethod(6); // 수행되지 않는다.
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
