﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEx2
{
    delegate int MyDelegate(int a, int b);

    class SumSubtract
    {
        public int Sum(int a, int b)
        {
            return a + b;
        }

        public static int Subtract(int a, int b)
        {
            return a - b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SumSubtract ss = new SumSubtract();
            MyDelegate md = new MyDelegate(ss.Sum);

            Console.WriteLine(md(1, 2));
            md = new MyDelegate(SumSubtract.Subtract);
            Console.WriteLine(md(10, 4));
        }
    }
}
