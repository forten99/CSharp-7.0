﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEx4
{

    delegate int CalDelegate(int x, int y);
    class Program
    {
        static int Add(int x, int y)
        {
            return x + y;
        }

        static int Sub(int x, int y)
        {
            return x - y;
        }

        public static void Calc(int x, int y, CalDelegate cd)
        {
            Console.WriteLine(cd(x, y));
        }

        static void Main(string[] args)
        {
            CalDelegate Plus = Add;
            CalDelegate Minus = Sub;

            Calc(11, 22, Plus);
            Calc(22, 11, Minus);
        }
    }
}
