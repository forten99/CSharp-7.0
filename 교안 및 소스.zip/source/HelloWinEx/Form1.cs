﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWinEx
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Hello_Click(object sender, EventArgs e)
        {
            //Hello.Text = "안녕하세요 c# 윈도우 폼 프로그래밍!!";

            //int a = 100;
            //int b = 200;

            //int hap = a + b;

            //Hello.Text = hap.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = 500;

            Hello.Text = num.ToString();
        }
    }
}
